# STM32-Bootloader
STM32 Custom Bootloader from scratch - Bootloader Tutorial series.

Please check the text explanation.

git - https://github.com/Embetronicx/STM32-Bootloader/tree/main/Bootloader_Example
Web version - https://embetronicx.com/bootloader-tutorials/

Video version - https://www.youtube.com/watch?v=jzo7z2gNBgg&list=PLArwqFvBIlwHRgPtsQAhgZavlp42qpkiG

# RS-232
RS-232 for Linux, FreeBSD and windows

Website: https://www.teuniz.net/RS-232/

No merge requests. If you want to report a bug, create an issue.


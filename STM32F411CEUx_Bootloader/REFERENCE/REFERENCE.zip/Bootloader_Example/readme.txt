This has the customized bootloader and application. This has been created to explain the bootloader and its implementation in STM32F767Zi (Cortex-M7) controller. 

You can find the complete Bootloader tutorial in the below link.
https://embetronicx.com/bootloader-tutorials/
